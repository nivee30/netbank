package com.inb.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inb.main.pojo.TransactionDetails;
import com.inb.main.repository.TransactiondetailsRepositoryInterface;
@Service
public class TransactionService implements TransactionServiceInterface {
	@Autowired
	TransactiondetailsRepositoryInterface transactiondetailsRepositoryInterface;

	@Override
	public boolean addTransactionDetails(TransactionDetails transactionDetails) {
	
		return transactiondetailsRepositoryInterface.addTransactionDetails(transactionDetails);
	}

	@Override
	public List<TransactionDetails> getAllTransactionDetails() {
	
		return transactiondetailsRepositoryInterface.getAllTransactionDetails();
	}

	@Override
	public List<TransactionDetails> transactionDetailsByAccountId(String accountId) {
	
		return transactiondetailsRepositoryInterface.transactionDetailsByAccountId(accountId);
	}

	@Override
	public List<TransactionDetails> transactionDetailsByTransactiontId(int transactionId) {
		// TODO Auto-generated method stub
		return transactiondetailsRepositoryInterface.transactionDetailsByTransactiontId(transactionId);
	}

	@Override
	public boolean accountTransferTransaction(TransactionDetails transactionDetails) {
	
		
		return transactiondetailsRepositoryInterface.accountTransferTransaction(transactionDetails);
	}

	

}
