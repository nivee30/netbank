package com.inb.main.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inb.main.pojo.AccountDetails;
import com.inb.main.pojo.TransactionDetails;
import com.inb.main.service.AccountDetailsServiceInterface;
import com.inb.main.service.TransactionServiceInterface;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("netbankingapi")
public class TransactiondetailsController {
	@Autowired
	TransactionServiceInterface transactionServiceInterface;
	@Autowired
	AccountDetailsServiceInterface accountDetailsServiceInterface;

	@RequestMapping(value = "transactiondetails/addnew", method = RequestMethod.POST)
	boolean addTransactionDetails(TransactionDetails transactionDetails) {
		return transactionServiceInterface.addTransactionDetails(transactionDetails);

	}

	@RequestMapping(value = "transactiondetails/getall", method = RequestMethod.GET)
	List<TransactionDetails> getAllTransactionDetails() {
		return transactionServiceInterface.getAllTransactionDetails();

	}

	@RequestMapping(value = "transactiondetails/{accountId}", method = RequestMethod.GET)
	public List<TransactionDetails> transactionDetailsByAccountId(@PathVariable String accountId) {
		return transactionServiceInterface.transactionDetailsByAccountId(accountId);
	}

	@RequestMapping(value = "transactiondetail/{transactionId}", method = RequestMethod.GET)
	public List<TransactionDetails> transactionDetailsByTransactiontId(@PathVariable int transactionId) {
		Object args[] = { transactionId };

		return transactionServiceInterface.transactionDetailsByTransactiontId(transactionId);
	}

	@RequestMapping(value = "transactiondetail/transfer", method = RequestMethod.PUT)
	public boolean accountTransferTransaction(@RequestBody TransactionDetails transactionDetails) {
		System.out.println(transactionDetails);

		AccountDetails accountDetailsFrom = transactionDetails.getAccountId();
		accountDetailsFrom = accountDetailsServiceInterface
				.getAccountDetailsByAccountId(accountDetailsFrom.getAccountId());
	

		AccountDetails accountDetailsTo = transactionDetails.getAccountIdTo();
		accountDetailsTo = accountDetailsServiceInterface.getAccountDetailsByAccountId(accountDetailsTo.getAccountId());
		
		if (accountDetailsFrom.getCurrentBalance() >= transactionDetails.getTransactionAmount()) {
			double amount =  transactionDetails.getTransactionAmount();
			
			accountDetailsFrom.setCurrentBalance(accountDetailsFrom.getCurrentBalance() - amount);
			
			TransactionDetails withdrawTransaction = new TransactionDetails();
			withdrawTransaction.setAccountId(accountDetailsFrom);
			withdrawTransaction.setAccountIdTo(accountDetailsTo);
			withdrawTransaction.setTransactionAmount(amount);
			withdrawTransaction.setTransactionType("Withdraw");
			withdrawTransaction.setTransactionDate(LocalDate.now());
			withdrawTransaction.setTransactionTime(LocalTime.now());
			
			boolean withdrawTransactionStatus = transactionServiceInterface.addTransactionDetails(withdrawTransaction);

			
			accountDetailsTo.setCurrentBalance(accountDetailsTo.getCurrentBalance() + amount);
			
			TransactionDetails depositTransaction = new TransactionDetails();
			depositTransaction.setAccountId(accountDetailsFrom);
			depositTransaction.setAccountIdTo(accountDetailsTo);
			depositTransaction.setTransactionAmount(amount);
			depositTransaction.setTransactionType("Withdraw");
			depositTransaction.setTransactionDate(LocalDate.now());
			depositTransaction.setTransactionTime(LocalTime.now());
						
			boolean depositTransactionStatus = transactionServiceInterface.addTransactionDetails(depositTransaction);
			
			if (withdrawTransactionStatus == true && depositTransactionStatus == true) {
				boolean updateAccountToBalanceStatus = accountDetailsServiceInterface
						.updateAccountDetails(accountDetailsTo);

				boolean updateAccountFromBalanceStatus = accountDetailsServiceInterface
						.updateAccountDetails(accountDetailsFrom);
				if (updateAccountToBalanceStatus && updateAccountFromBalanceStatus) {
					System.out.println("Transaction Success");
					return true;
				}
			}
		}
		return false;
	}

}
