package com.inb.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inb.main.pojo.BankSlipDetails;
import com.inb.main.repository.BankSlipRepository;
@Service
public class BankSlipService implements BankSlipServiceInterface{
	@Autowired
	BankSlipRepository bankSlipRepository;

	@Override
	public boolean addBankSlipDetails(BankSlipDetails bankSlipDetails) {
		// TODO Auto-generated method stub
		return bankSlipRepository.addBankSlipDetails(bankSlipDetails);
	}

	@Override
	public List<BankSlipDetails> getAllBankSlipDetails() {
		
		return bankSlipRepository.getAllBankSlipDetails();
	}

	@Override
	public BankSlipDetails getBankSlipByChequeNo(int chequeNo) {
		// TODO Auto-generated method stub
		return bankSlipRepository.getBankSlipByChequeNo(chequeNo);
	}

	@Override
	public List<BankSlipDetails> getBankSlipByAccountId(int accountId) {
	
		return bankSlipRepository.getBankSlipByAccountId(accountId);
	}



}
