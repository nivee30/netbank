package com.inb.main.repository;

import java.util.List;

import com.inb.main.pojo.BankSlipDetails;

public interface BankSlipRepositoryInterface {
	boolean addBankSlipDetails(BankSlipDetails bankSlipDetails);

	List<BankSlipDetails> getAllBankSlipDetails();

	BankSlipDetails getBankSlipByChequeNo(int chequeNo);
	
	List<BankSlipDetails> getBankSlipByAccountId(int accountId);
	

}
